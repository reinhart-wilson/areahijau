
const formSearch = document.getElementById('form-search');
const containerMap = document.getElementById('container-map');
const selectTahun1 = document.getElementById('search-tahun-1');
const selectTahun2 = document.getElementById('search-tahun-2');
const submitSearch = formSearch.querySelector('input[type="submit"]');
const overlay = document.getElementById('overlay')
const canvasChart = document.getElementById('canvas-chart')
const tbKelurahan = document.getElementById('detail-kelurahan')
const tbLuas = document.getElementById('detail-luas')
const tbPerubahan = document.getElementById('detail-perubahan')

// ============================================================================

const selectKelurahan = document.getElementById('search-kelurahan');
const selectKecamatan = document.getElementById('search-kecamatan');
const selectProvinsi = document.getElementById('search-provinsi');
const selectKota = document.getElementById('search-kota');

// ============================================================================

var canvases;
var contexts;

const basicCanvas = document.getElementById('canvas-basic');
const changesCanvas = document.getElementById('canvas-changes');
const tahun1Canvas = document.getElementById('canvas-tahun1');
const tahun2Canvas = document.getElementById('canvas-tahun2');
canvases = [basicCanvas, changesCanvas, tahun1Canvas, tahun2Canvas];

const basicContext = basicCanvas.getContext('2d');
const changesContext = changesCanvas.getContext('2d');
const tahun1Context = tahun1Canvas.getContext('2d');
const tahun2Context = tahun2Canvas.getContext('2d');
contexts = [basicContext, changesContext, tahun1Context, tahun2Context]

// ============================================================================

const defYear = selectTahun1.firstElementChild.cloneNode(true);
const defChoice = selectTahun1.firstElementChild.cloneNode(true);
let choicesKelurahan = null;
var squaredText = document.createElement('sup');
squaredText.innerText = 2;
var reportChart;

// Memeriksa apakah value adalah tahun
function isYear(value) {
  if ((typeof value === 'number' || typeof value === 'string') && parseInt(value) > 0) {
    if (value.toString().length === 4) {
      return true;
    }
  }
  return false;
}

const toggleVisibility = (element) => {
  if (element.classList.contains('hidden')){
    element.classList.remove('hidden');
    return;
  }
  element.classList.add('hidden');
}

// Fungsi untuk menggambar grafik pada canvas
const generateGraph = (canvas, data, label) => {
  if (reportChart != null) {
    reportChart.destroy();
  }

  const config = {
    type: "line",
    data: {
      labels: label,
      datasets: [
        {
          data: data,
          backgroundColor: "indianRed",
          borderColor: "coral",
        },
      ],
    },
    options: {
      scales: {
        x: {
          title: {
            display: true,
            text: "Tahun",
            color: "#292929",
            font: {
              size: 18,
            },
          },
        },
        y: {
          beginAtZero: false,
          title: {
            display: true,
            text: "Luas Area Hijau (m^2)",
            color: "#292929",
            font: {
              size: 18,
            },
          },
        },
      },
      plugins: {
        legend: {
          display: false,
        },
        title: {
          display: true,
          text: "Area Hijau",
          color: "#CD5C5C",
          font: {
            size: 24,
          },
        },
      },
    },
  };
  reportChart = new Chart(canvas.getContext("2d"), config);
}

// Fungsi untuk menggambar peta pada canvas
const generateMap = (csvData) => {

  // Tentukan koordinat maksimal untuk ukuran canvas dan buat canvas kosong
  const lastRow = csvData.data[csvData.data.length - 1];
  for (let canvas of canvases) {
    canvas.width = lastRow['x'];
    canvas.height = lastRow['y'];
    canvas.getContext('2d').clearRect(0, 0, canvas.width, canvas.height);
  }

  for (const csvRow of csvData.data) {
    let x = csvRow.x;
    let y = csvRow.y;
    const warna = csvRow.warna

    let totalBandVal = 0;
    const contextsToFill = []

    if (warna === 'g') {
      tahun1Context.fillStyle = 'green';
      tahun2Context.fillStyle = 'green';
      contextsToFill.push(tahun1Context);
      contextsToFill.push(tahun2Context);
    } else if (warna === 'w') {
      basicContext.fillStyle = 'white'
      contextsToFill.push(basicContext);
    } else if (warna === 'b') {
      changesContext.fillStyle = 'blue';
      tahun2Context.fillStyle = 'green';
      contextsToFill.push(changesContext);
      contextsToFill.push(tahun2Context);
    } else if (warna === 'r') {
      tahun1Context.fillStyle = 'green';
      changesContext.fillStyle = 'red';
      contextsToFill.push(changesContext);
      contextsToFill.push(tahun1Context);
      // perubahanLuas += 1;
    } else {
      basicContext.fillStyle = 'black';
      contextsToFill.push(basicContext);
    }


    // Isi luas
    // tbLuas.innerText = "" + (luasHijau * 10 * 10) + " m";
    // tbPerubahan.innerText = "" + (perubahanLuas * 10 * 10) + " m";
    // tbLuas.appendChild(squaredText.cloneNode(true));
    // tbPerubahan.appendChild(squaredText.cloneNode(true));
    for (let context of contextsToFill) {
      context.fillRect(x, y, 1, 1);
    }
  }

  // Tampilkan di kontainer
  for (let canvas of canvases) {
    canvas.style.height = '100%';
    canvas.style.width = 'auto';
    canvas.style.imageRendering = 'pixelated';
  }

  tahun2Canvas.classList.add('hidden');

  // Sembunyikan overlay
  overlay.classList.add('hidden');
}

// ============================================================================

document.addEventListener('DOMContentLoaded', async function () {
  //
  selectProvinsi.addEventListener('change', async (event) => {
    submitSearch.disabled = true;
    selectKecamatan.disabled = true;
    selectKota.disabled = true;
    selectKelurahan.disabled = true;
    selectTahun1.disabled = true;
    selectTahun2.disabled = true;
    submitSearch.disabled = true;

    const selectedChoice = event.target;
    const selectedId = selectedChoice.value;

    // AJAX get kota tersedia
    const url = `ajaxKota?idProvinsi=${selectedId}`;
    const response = await fetch(url);
    const kotas = await response.json();

    // Ganti opsi kota
    selectKota.innerHTML = ""; // Hapus semua opsi
    const defKota = defChoice.cloneNode(true);
    defKota.innerText = "-- Pilih Kota --";
    selectKota.appendChild(defKota); // Opsi default
    if (kotas.length) {
      for (let row of kotas) {
        const newOpt = document.createElement("option");
        newOpt.value = row.idKota;
        newOpt.innerText = row.namaKota;
        if (row.isKabupaten === 1) newOpt.innerText += " KABUPATEN"
        selectKota.appendChild(newOpt);
        selectKota.disabled = false;
      }
    }
  })

  // Event listener select kota
  selectKota.addEventListener('change', async (event) => {
    submitSearch.disabled = true;
    selectKecamatan.disabled = true;
    selectKelurahan.disabled = true;
    selectTahun1.disabled = true;
    selectTahun2.disabled = true;
    submitSearch.disabled = true;

    const selectedChoice = event.target;
    const selectedId = selectedChoice.value;

    // AJAX get kota tersedia
    const url = `ajaxKecamatan?idKota=${selectedId}`;
    const response = await fetch(url);
    const data = await response.json();

    // Ganti opsi kota
    const defSelect = defChoice.cloneNode(true); // opsi default
    defSelect.innerText = "-- Pilih Kecamatan --";
    selectKecamatan.innerHTML = ""; // Hapus semua opsi
    selectKecamatan.appendChild(defSelect); // Opsi default
    if (data.length) {
      for (let row of data) {
        const newOpt = document.createElement("option");
        newOpt.value = row.idKecamatan;
        newOpt.innerText = row.namaKecamatan;
        selectKecamatan.appendChild(newOpt);
        selectKecamatan.disabled = false;
      }
    }
  })

  // Event listener select kecamatan
  selectKecamatan.addEventListener('change', async (event) => {
    submitSearch.disabled = true;
    selectKelurahan.disabled = true;
    selectTahun1.disabled = true;
    selectTahun2.disabled = true;
    submitSearch.disabled = true;

    const selectedChoice = event.target;
    const selectedId = selectedChoice.value;

    // AJAX get kota tersedia
    const url = `ajaxKelurahan?idKecamatan=${selectedId}`;
    const response = await fetch(url);
    const data = await response.json();

    // Ganti opsi kota
    const defSelect = defChoice.cloneNode(true); // opsi default
    defSelect.innerText = "-- Pilih Kelurahan --";
    selectKelurahan.innerHTML = ""; // Hapus semua opsi
    selectKelurahan.appendChild(defSelect); // Opsi default
    if (data.length) {
      for (let row of data) {
        const newOpt = document.createElement("option");
        newOpt.value = row.idKelurahan;
        newOpt.innerText = row.namaKelurahan;
        selectKelurahan.appendChild(newOpt);
        selectKelurahan.disabled = false;
      }
    }
  })

  // Tambahkan event listener ke dropdown kelurahan
  selectKelurahan.addEventListener('change', async (event) => {
    submitSearch.disabled = true;
    selectTahun1.disabled = true;
    selectTahun2.disabled = true;

    const selectedChoice = event.target;
    const selectedId = selectedChoice.value;

    // AJAX get tahun-tahun tersedia
    const url = `ajaxTahun?idKelurahan=${selectedId}`;
    const response = await fetch(url);
    const tahuns = await response.json();

    // Ganti opsi tahun
    selectTahun1.innerHTML = ""; // Hapus semua opsi
    selectTahun2.innerHTML = "";
    selectTahun1.appendChild(defYear.cloneNode(true)); // Opsi default
    selectTahun2.appendChild(defYear.cloneNode(true));
    if (tahuns.length) {
      for (let year of tahuns) {
        const newOpt = document.createElement("option");
        newOpt.value = year;
        newOpt.innerText = year;
        selectTahun1.appendChild(newOpt);
        selectTahun2.appendChild(newOpt.cloneNode(true));
      }
    } else {
      submitSearch.disabled = true;
    }

    // Request luas ke server
    const urlLuas = `ajaxLuas?idKelurahan=${selectedId}`;
    const responseLuas = await fetch(urlLuas);
    const luases = await responseLuas.json();

    // Buat grafik
    generateGraph(canvasChart, luases, tahuns)

    // Isi nama kelurahan
    tbKelurahan.innerHTML = selectedChoice.label;

    // Enable dropdown tahun
    selectTahun1.disabled = false;
    selectTahun2.disabled = false;
  })

  // Tambahkan event listener ke dropdown tahun
  selectTahun1.addEventListener('change', function (event) {
    if (isYear(selectTahun1.value) & isYear(selectTahun2.value))
      submitSearch.disabled = false;
    else submitSearch.disabled = true;
  });
  selectTahun2.addEventListener('change', function (event) {
    if (isYear(selectTahun1.value) & isYear(selectTahun2.value))
      submitSearch.disabled = false;
    else submitSearch.disabled = true;
  });
});

// ============================================================================

formSearch.addEventListener('submit', async function (event) {
  event.preventDefault();

  // Ambil data dari form
  const idKelurahan = selectKelurahan.value;
  const tahun1 = selectTahun1.value;
  const tahun2 = selectTahun2.value;
  const url = `ajaxMap?idKelurahan=${idKelurahan}&tahun1=${tahun1}&tahun2=${tahun2}`;

  // AJAX ambil data gambar
  overlay.classList.remove('hidden'); // tampilkan overlay untuk memberi tahu data sedang di-load
  const response = await fetch(url);
  const csvData = await response.text();
  const results = Papa.parse(csvData, {
    header: true,
    dynamicTyping: true,
    complete: (results) => {
      generateMap(results);
    }
  });
});

// ============================================================================

const radioTahun1 = document.getElementById('radio-tahun1');
const radioTahun2 = document.getElementById('radio-tahun2');
const radioTahunNone = document.getElementById('radio-tahunnone');

radioTahun1.addEventListener('input', (event) => {
  tahun2Canvas.classList.add('hidden');
  tahun1Canvas.classList.remove('hidden');
})

radioTahun2.addEventListener('input', (event) => {
  tahun2Canvas.classList.remove('hidden');
  tahun1Canvas.classList.add('hidden');
})

radioTahunNone.addEventListener('input', (event) => {
  tahun2Canvas.classList.add('hidden');
  tahun1Canvas.classList.add('hidden');
})

const radioYa = document.getElementById('radio-ya');
const radioTidak = document.getElementById('radio-tidak');

radioYa.addEventListener('input', (event)=>{
  changesCanvas.classList.remove('hidden')
})

radioTidak.addEventListener('input', (event)=>{
  changesCanvas.classList.add('hidden')
})
